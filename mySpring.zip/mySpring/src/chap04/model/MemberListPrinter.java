package chap04.model;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class MemberListPrinter {

	private MemberDao memberDao;
	//private MemberPrinter memberPrinter2;
	private MemberPrinter printer;
	
	public MemberListPrinter() {
		// TODO Auto-generated constructor stub
	}
	
	/*
	public MemberListPrinter(MemberDao memberDao, MemberPrinter printer) {
		this.memberDao = memberDao;
		this.printer = printer;
	}
	*/
	
	@Autowired
	public void setMamberDao(MemberDao memberDao) {
		this.memberDao = memberDao;
	}
	
	// =>빈 이름으로 식별
	//public void setPrinter(MemberPrinter memberPrinter2)
	// 힌정자를 필드의 이름으로 사용할 수 없다 !
	//public void setPrinter(MemberPrinter printerQ)
	// 한정자 사용
	/*@Qualifier("printerQ")
	public void setPrinter(MemberPrinter printer) {
		this.printer = printer;
	}*/
	
	//한정자를 이용한 자식 클래스(MemberSummaryPrinter) 빈 적용
	@Autowired
	@Qualifier("printerC")
	public void setPrinter(MemberPrinter printer) {
		this.printer = printer;
	}
	
	public void printAll() {
		Collection<Member> members = memberDao.selectAll();
		members.forEach(m -> printer.print(m));
	}
}
