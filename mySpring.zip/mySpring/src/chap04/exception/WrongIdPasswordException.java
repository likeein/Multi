package chap04.exception;

public class WrongIdPasswordException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
