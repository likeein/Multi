package chap03.model;

import org.springframework.beans.factory.annotation.Autowired;

import chap03.exception.MemberNotFoundException;

public class MemberInfoPrinter {
	
	@Autowired
	private MemberDao memberDao;
	@Autowired
	private MemberPrinter printer;
	
	public MemberInfoPrinter() {
	}
	
	/*
	public void setMemberDao(MemberDao memberDao) {
		this.memberDao = memberDao;
	}
	
	public void setMemberPrinter(MemberPrinter printer) {
		this.printer = printer;
	}
	*/
	
	public void printMemberInfo(String email) {
		Member member = this.memberDao.selectByEmail(email);
		
		if(member == null) {
			throw new MemberNotFoundException();
		}
		
		printer.print(member);
		System.out.println();
	}
}
