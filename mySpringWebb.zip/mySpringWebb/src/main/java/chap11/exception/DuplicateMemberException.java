package chap11.exception;

public class DuplicateMemberException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
