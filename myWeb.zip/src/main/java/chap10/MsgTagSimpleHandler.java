package chap10;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MsgTagSimpleHandler extends SimpleTagSupport{

	@Override
	public void doTag() throws IOException{
		JspWriter outJspWriter = getJspContext().getOut();
		outJspWriter.println("커스텀 태그 메시지 출력 : Hello World!");
	}
}
