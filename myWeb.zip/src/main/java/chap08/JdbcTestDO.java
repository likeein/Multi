package chap08;

public class JdbcTestDO {

	private String username;
	private String email;
	
	public JdbcTestDO() {
		// TODO Auto-generated constructor stub
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getEmail() {
		return email;
	}
}
