package chap07;

public class LoginBean {

	private String id;
	private String passwd;
	
	public LoginBean() {
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	
	public String getId() {
		return this.id;
	}
	
	public String getPasswd() {
		return this.passwd;
	}
	
	public boolean checkLogin() {
		final String ID = "longlee";
		final String PASSWD = "6789";
		boolean result = false;
		
		if(this.id != null && this.id.equals(ID) && this.passwd != null && this.passwd.equals(PASSWD)) {
			result = true;
		}
		
		return result;
	}
}











